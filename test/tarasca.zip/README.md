tarasca-wallet readme
